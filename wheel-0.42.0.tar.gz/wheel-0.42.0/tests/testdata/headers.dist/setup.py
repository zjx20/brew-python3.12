from __future__ import annotations

from setuptools import setup

setup(
    name="headers.dist",
    version="0.1",
    description="A distribution with headers",
    headers=["header.h"],
)
